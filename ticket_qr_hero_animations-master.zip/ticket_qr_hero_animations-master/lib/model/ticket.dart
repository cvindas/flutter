class Ticket {
  String id;
  String sourceStation;
  String destinationStation;
  String sourceCity;
  String destinationCity;
  String departureTime;
  String arrivalTime;
  String terminal;
  String game;
  String boardingTime;
}