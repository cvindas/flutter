var images = [
  "assets/image_01.png",
  "assets/image_02.png",
  "assets/image_03.png",
];

var title = ["Hemes ArmChair", "Sofar ArmChari", "Wooden ArmChair"];
var price = ["126", "148", "179"];
