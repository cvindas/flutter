import 'package:flutter/material.dart';

class CustomIcons {
  static const IconData search = IconData(0xe900, fontFamily: "CustomICons");
  static const IconData menu = IconData(0xe901, fontFamily: "CustomICons");
}
