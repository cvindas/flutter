# Flutter Crash Course Repo: Creating a full app from scratch

## Screenshots
<img src="https://raw.githubusercontent.com/bramvbilsen/Flutter-Quiz-Preview-App/master/screenshots/Screenshot_1519245085.png" width="200">   <img src="https://raw.githubusercontent.com/bramvbilsen/Flutter-Quiz-Preview-App/master/screenshots/Screenshot_1519245074.png" width="200">   <img src="https://raw.githubusercontent.com/bramvbilsen/Flutter-Quiz-Preview-App/master/screenshots/Screenshot_1519245082.png" width="200">   <img src="https://raw.githubusercontent.com/bramvbilsen/Flutter-Quiz-Preview-App/master/screenshots/Screenshot_1519244338.png" width="200">

## Video Crash Course
This repo contains the code for a flutter crash course that you can find on youtube: https://youtu.be/jBBl1tYkUnE

## Getting Started

For help getting started with Flutter, view our online
[documentation](http://flutter.io/).
