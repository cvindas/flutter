import 'package:flutter/material.dart';
import 'package:flutter_app_products/ui/listview_product.dart';

void main() => runApp(new MaterialApp(
  home: ListViewProduct(),
  title: 'Product Db',
));

