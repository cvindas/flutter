# dart_flutter_chat_app

#### In this tutorial we build out a simple chat application using dart's flutter framework. 

### Check out the Youtube Tutorial for this [Dart Flutter Program](https://youtu.be/WwhyaqNtNQY). Here is our [Youtube Channel](https://www.youtube.com/channel/UCYqCZOwHbnPwyjawKfE21wg) Subscribe for more content.

### Check out our blog at [tensor-programming.com](http://tensor-programming.com/).

### Our [Twitter](https://twitter.com/TensorProgram), our [facebook](https://www.facebook.com/Tensor-Programming-1197847143611799/) and our [Steemit](https://steemit.com/@tensor).

### Donate if you like the content:
### Ada: DdzFFzCqrhsqPcLbpt3C9nkSW2HvMJJCER5c9ijxKwXDet3GT5KchnUp458zN9uVmCzRjzwyy8usFUEhwBQ63h2ZjvyAXHYnHRG8MZpv
### Eth: 0xD210Ea51F1615794A16080A108d2BC5471F60166
### Ltc: LXsKxF5JhmMtKgqfcUFdvcXVwiaSqxN9cP
