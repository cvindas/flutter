# WordPair Generator

Flutter crash course project based on the documentation project

Generate random word pairs and add pairs to favorites

[Flutter Setup Gist](https://gist.github.com/bradtraversy/f1af78251962bb210c2ebe5b4f9a5c35)
