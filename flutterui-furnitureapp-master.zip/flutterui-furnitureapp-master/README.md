# Furniture_UI

Screen design of a Furniture app using Flutter.

Design credit - https://dribbble.com/shots/5601479-Furniture-app/attachments/1210953

How do I code this - https://youtu.be/ZtPe6Zu6BA4

Screenshots

![screenshot_20181203-232850](https://user-images.githubusercontent.com/8137504/49392298-09e33980-f754-11e8-9fc2-7cd12b62e604.png)
